#!/bin/bash

# Copyright 2016 F5 Networks, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

USAGE_SHORT="Usage: $0"
read -r -d '' USAGE_LONG << EOM
    Usage: $0
        -h|--help         Print this message and exit.
EOM

ARGS=`getopt -o h --long help -n $0 -- "$@"`
if [ $? -ne 0 ]; then
    echo $USAGE_SHORT
    exit
fi

eval set -- "$ARGS"

# Defaults
HELP=false

# Parse the command line arguments
while true; do
    case "$1" in
        -h|--help)
            HELP=true;
            shift ;;
        --)
            shift
            break;;
    esac
done

if [ $HELP = true ]; then
    echo "$USAGE_LONG"
    exit
fi

. ../util.sh

# Get the management IP address. Need to wait till it's available via ifconfig
# since tmsh will have the DHCP address before the correct management IP is ready
# Then need wait till tmsh agrees since that is updated after eth0 is configured
function wait_for_management_ip() {
    RETRY_INTERVAL=10
    MAX_TRIES=60
    failed=0

    while true; do
        MGMT_ADDR_TMSH=$(tmsh list sys management-ip | awk '/management-ip/ {print $3}' | awk -F "/" '{print $1}')
        MGMT_ADDR_ETH0=`ifconfig eth0 | egrep "inet addr" | awk -F: '{print $2}' | awk '{print $1}'`

        if [[ $MGMT_ADDR_TMSH != $MGMT_ADDR_ETH0 ]]; then
            echo "Management IP and eth0 not yet in sync."
        elif [ -n $MGMT_ADDR_TMSH ]; then
            MGMT_ADDR=$MGMT_ADDR_TMSH
            return 0
        fi

        if [[ $failed -ge $MAX_TRIES ]]; then
            echo "Failed to get management IP after $failed attempts."
            return 1
        fi

        ((failed=failed+1))
        sleep $RETRY_INTERVAL
    done
}

function wait_for_cidr_block() {
    RETRY_INTERVAL=2
    MAX_TRIES=60
    failed=0

    GATEWAY_CIDR_BLOCK=`curl http://169.254.169.254/latest/meta-data/network/interfaces/macs/${GATEWAY_MAC}/subnet-ipv4-cidr-block`
    while [ -z "$GATEWAY_CIDR_BLOCK" ] && [[ $failed -lt $MAX_TRIES ]]; do
        sleep $RETRY_INTERVAL
        ((failed=failed+1))
        GATEWAY_CIDR_BLOCK=`curl http://169.254.169.254/latest/meta-data/network/interfaces/macs/${GATEWAY_MAC}/subnet-ipv4-cidr-block`
    done
}

wait_mcp_running
if [ $? -ne 0 ]; then
    echo "mcpd not ready in time."
    exit 1
fi

wait_for_management_ip
if [ $? -ne 0 ]; then
    echo "Could not get management ip."
    exit 1
fi

echo MGMT_ADDR: "$MGMT_ADDR"

# Get the Gateway info
GATEWAY_MAC=`ifconfig eth0 | egrep HWaddr | awk '{print tolower($5)}'`
echo GATEWAY_MAC: "$GATEWAY_MAC"

wait_for_cidr_block
echo GATEWAY_CIDR_BLOCK: "$GATEWAY_CIDR_BLOCK"

GATEWAY_NET=${GATEWAY_CIDR_BLOCK%/*}
echo GATEWAY_NET: "$GATEWAY_NET"

GATEWAY_PREFIX=${GATEWAY_CIDR_BLOCK#*/}
echo GATEWAY_PREFIX: "$GATEWAY_PREFIX"

GATEWAY=`echo $GATEWAY_NET | awk -F. '{ printf "%d.%d.%d.%d", $1, $2, $3, $4+1 }'`
echo GATEWAY: "$GATEWAY"

# Create the network
echo tmsh create net vlan external interfaces add { 1.0 }
tmsh create net vlan external interfaces add { 1.0 }

echo tmsh create net self "$MGMT_ADDR"/$GATEWAY_PREFIX vlan external allow-service default
tmsh create net self "$MGMT_ADDR"/$GATEWAY_PREFIX vlan external allow-service default

echo tmsh create sys folder /LOCAL_ONLY device-group none traffic-group traffic-group-local-only
tmsh create sys folder /LOCAL_ONLY device-group none traffic-group traffic-group-local-only

echo tmsh create net route /LOCAL_ONLY/default network default gw "$GATEWAY"
tmsh create net route /LOCAL_ONLY/default network default gw "$GATEWAY"
